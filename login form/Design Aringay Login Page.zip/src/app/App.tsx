import { useState, type FormEvent } from "react";
import { ArrowRight, Bell, Check, CheckCircle2, ChevronRight, Eye, EyeOff, Leaf, LoaderCircle, LockKeyhole, Mail, MapPin, Package, ShieldCheck, Sprout, Tractor, Truck, Users, AlertCircle } from "lucide-react";

function FarmerRegistration({ onSignIn }: { onSignIn: () => void }) {
  const [values, setValues] = useState({ fullName: "", phone: "", address: "", email: "", password: "", confirmPassword: "" });
  const [attempted, setAttempted] = useState(false);
  const [visible, setVisible] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const errors = {
    fullName: values.fullName.trim() ? "" : "Enter your full name.",
    phone: /^\+?[\d\s()-]{10,16}$/.test(values.phone.trim()) ? "" : "Enter a valid contact number.",
    address: values.address.trim() ? "" : "Enter your barangay and address.",
    email: /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email) ? "" : "Enter a valid email address.",
    password: values.password.length >= 8 ? "" : "Use at least 8 characters.",
    confirmPassword: values.confirmPassword && values.confirmPassword === values.password ? "" : "Passwords must match.",
  };
  const fields = [
    { key: "fullName", label: "Full Name", placeholder: "Juan Dela Cruz", autocomplete: "name", type: "text" },
    { key: "phone", label: "Contact Number", placeholder: "09XX XXX XXXX", autocomplete: "tel", type: "tel" },
    { key: "address", label: "Barangay / Address", placeholder: "Barangay, street or sitio in Aringay", autocomplete: "street-address", type: "text" },
    { key: "email", label: "Email Address", placeholder: "Enter your email address", autocomplete: "email", type: "email" },
    { key: "password", label: "Password", placeholder: "Create a password", autocomplete: "new-password", type: "password" },
    { key: "confirmPassword", label: "Confirm Password", placeholder: "Re-enter your password", autocomplete: "new-password", type: "password" },
  ] as const;
  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setAttempted(true);
    setMessage("");
    if (Object.values(errors).some(Boolean)) return;
    setLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1100));
    setLoading(false);
    setMessage("This is a design preview. Farmer registration is not connected yet; no account has been created.");
  }
  return (
    <div className="mx-auto flex w-full max-w-[440px] flex-1 flex-col justify-center py-10">
      <button type="button" onClick={onSignIn} disabled={loading} className="mb-6 flex min-h-10 w-fit items-center gap-2 rounded text-xs text-[#69756d] hover:text-[#166534] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#166534] disabled:opacity-50"><ArrowRight size={14} className="rotate-180" /> Back to sign in</button>
      <div className="mb-3 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[1.6px] text-[#43815d]"><Sprout size={14} /> Farmer registration</div>
      <h1 className="text-[34px] font-semibold leading-[1.2] tracking-[-0.8px] lg:text-[38px]">Grow with us<span className="text-[#32865b]">.</span></h1>
      <p className="mt-3 text-sm leading-6 text-[#7a827e]">Create your farmer account and connect with the Aringay agriculture community.</p>
      <form onSubmit={submit} noValidate className="mt-7">
        {message && <div role="status" className="mb-5 flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs leading-5 text-amber-900"><AlertCircle size={17} className="mt-0.5 shrink-0" />{message}</div>}
        <div className="grid grid-cols-1 gap-x-4 gap-y-4 sm:grid-cols-2 md:grid-cols-1 xl:grid-cols-2">
          {fields.map((field) => {
            const invalid = attempted && Boolean(errors[field.key]);
            const passwordField = field.type === "password";
            return (
              <div key={field.key} className={field.key === "address" || field.key === "email" ? "sm:col-span-2 md:col-span-1 xl:col-span-2" : ""}>
                <label htmlFor={`register-${field.key}`} className="mb-2 block text-[12px] font-semibold">{field.label}</label>
                <div className="relative">
                  <input id={`register-${field.key}`} name={field.key} type={passwordField && visible ? "text" : field.type} autoComplete={field.autocomplete} required disabled={loading} value={values[field.key]} placeholder={field.placeholder} aria-invalid={invalid} aria-describedby={invalid ? `${field.key}-error` : field.key === "password" ? "password-hint" : undefined} onChange={(event) => { setValues({ ...values, [field.key]: event.target.value }); setMessage(""); }} className={`h-[50px] w-full rounded-[10px] border bg-white px-3.5 text-[13px] outline-none transition placeholder:text-[#a0a7a2] focus:border-[#27764b] focus:ring-4 focus:ring-[#166534]/10 disabled:bg-gray-50 disabled:opacity-60 ${invalid ? "border-red-400" : "border-[#dfe5e0]"} ${passwordField ? "pr-11" : ""}`} />
                  {passwordField && <button type="button" disabled={loading} onClick={() => setVisible(!visible)} aria-label={`${visible ? "Hide" : "Show"} ${field.label.toLowerCase()}`} aria-pressed={visible} className="absolute right-0.5 top-0.5 flex size-[46px] items-center justify-center rounded-md text-[#8b958e] hover:text-[#166534] focus-visible:outline-2 focus-visible:outline-[#166534]">{visible ? <EyeOff size={17} /> : <Eye size={17} />}</button>}
                </div>
                {invalid ? <p id={`${field.key}-error`} role="alert" className="mt-1.5 text-[11px] text-red-600">{errors[field.key]}</p> : field.key === "password" && <p id="password-hint" className="mt-1.5 text-[10px] text-[#7a827e]">Use at least 8 characters.</p>}
              </div>
            );
          })}
        </div>
        <button type="submit" disabled={loading} className="mt-6 flex h-[54px] w-full items-center justify-center gap-3 rounded-[10px] bg-[#17633f] text-sm font-semibold text-white shadow-sm transition hover:bg-[#104d30] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#166534] disabled:cursor-wait disabled:opacity-60">{loading ? <><LoaderCircle size={18} className="animate-spin motion-reduce:animate-none" />Creating account…</> : <>Register as Farmer<ArrowRight size={17} /></>}</button>
      </form>
      <p className="mt-5 text-center text-xs text-[#7a827e]">Already have an account? <button type="button" disabled={loading} onClick={onSignIn} className="min-h-10 rounded px-1 font-semibold text-[#17633f] hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#166534]">Sign in</button></p>
      <div className="mt-3 flex items-center justify-center gap-2 text-[10px] text-[#909992]"><ShieldCheck size={14} /> Your community. Your resources. One secure account.</div>
    </div>
  );
}

function AgricultureScene() {
  return (
    <div className="relative mx-auto aspect-[1.2] w-full max-w-[550px]" aria-hidden="true">
      <div className="absolute inset-x-[8%] top-[10%] aspect-square rounded-full border border-white/10" />
      <div className="absolute inset-x-[15%] top-[18%] aspect-square rounded-full border border-white/10" />
      <svg viewBox="0 0 600 440" className="absolute inset-0 h-full w-full" fill="none">
        <ellipse cx="300" cy="364" rx="236" ry="48" fill="#0a392a" fillOpacity=".4" />
        <path d="M62 273 300 164 544 271 307 389Z" fill="#9ebc74" />
        <path d="m62 273 245 116v22L62 295Z" fill="#6d9453" />
        <path d="m307 389 237-118v23L307 411Z" fill="#4f7949" />
        <path d="m73 271 234 108 73-36-235-105Z" fill="#65945a" />
        <path d="m158 232 233 105 68-34-229-102Z" fill="#b8c789" />
        <path d="m241 195 228 103 64-27-233-103Z" fill="#7ca362" />
        {[0, 1, 2, 3, 4, 5].map((row) => <path key={row} d={`M${85 + row * 12} ${264 - row * 5}l229 107`} stroke="#bfd297" strokeWidth="3" />)}
        {[0, 1, 2, 3, 4].map((row) => <path key={row} d={`M${252 + row * 14} ${190 - row * 6}l219 102`} stroke="#b1c77d" strokeWidth="3" />)}
        <path d="m198 273 58-27 62 28-58 28Z" fill="#e2dcc1" />
        <path d="M198 273v-67l57-26v66Z" fill="#eee8d4" />
        <path d="m255 180 62 28v66l-62-28Z" fill="#c5c7ac" />
        <path d="m184 210 70-61 78 63-17 8-61-44-54 41Z" fill="#d1ac6a" />
        <path d="m184 210 16 7 54-41v-27Z" fill="#e5c68d" />
        <path d="m214 266 23-11v-34l-23 11Z" fill="#315c43" />
        <path d="m274 222 22 10v20l-22-10Z" fill="#628978" />
        <path d="M264 270v-21m-8 10 8 5 9-10" stroke="#355e3e" strokeWidth="3" />
        <path d="M405 218v-67" stroke="#b7bd8a" strokeWidth="8" />
        <path d="M405 184c-43 0-48-29-43-40 29-1 44 12 43 40Z" fill="#a6bd75" />
        <path d="M405 171c0-32 19-49 41-46 7 21-4 42-41 46Z" fill="#d0dba0" />
        <path d="M462 247v-43m0 20c-25-2-30-16-26-23 18-1 28 8 26 23Zm0-9c1-20 13-31 27-28 4 14-3 26-27 28Z" stroke="#b3c983" strokeWidth="4" fill="#b3c983" />
        <path d="m351 310 39-18 37 17-38 19Z" fill="#d8ba7f" />
        <path d="m351 310 38 18v29l-38-18Z" fill="#b88d51" />
        <path d="m389 328 38-19v29l-38 19Z" fill="#cda56a" />
        <path d="m364 304 37 18v12" stroke="#ecdbb3" strokeWidth="6" />
      </svg>
      <div className="absolute left-[3%] top-[29%] flex items-center gap-3 rounded-xl border border-white/70 bg-[#fbfcf5] px-4 py-3 shadow-xl shadow-black/10">
        <div className="rounded-lg bg-[#e6eedc] p-2.5"><Users size={20} className="text-[#46613d]" /></div>
        <div><p className="text-[10px] font-medium text-[#7d8877]">Farmer records</p><p className="mt-0.5 text-sm font-semibold text-[#304832]">Connected & organized</p></div>
        <span className="ml-2 flex size-5 items-center justify-center rounded-full bg-[#deead4]"><Check size={12} className="text-[#46613d]" /></span>
      </div>
      <div className="absolute right-[0%] top-[47%] rounded-xl border border-white/70 bg-[#fbfcf5] px-4 py-3 shadow-xl shadow-black/10">
        <div className="flex items-center gap-2 text-[11px] font-semibold text-[#314a34]"><span className="rounded-md bg-[#e6eedc] p-1.5"><Package size={15} /></span> Resource distribution</div>
        <div className="mt-3 flex items-end gap-1.5"><span className="h-4 w-5 rounded-t bg-[#d8e4c9]" /><span className="h-7 w-5 rounded-t bg-[#cadbb7]" /><span className="h-5 w-5 rounded-t bg-[#afc799]" /><span className="h-9 w-5 rounded-t bg-[#93b279]" /><span className="h-11 w-5 rounded-t bg-[#61844e]" /><span className="h-14 w-5 rounded-t bg-[#386344]" /></div>
      </div>
      <div className="absolute bottom-[9%] left-[22%] flex items-center gap-2 rounded-full bg-[#fbfcf5] px-4 py-2.5 text-[11px] font-medium text-[#3f6245] shadow-lg shadow-black/10"><CheckCircle2 size={16} /> Growing a stronger community</div>
    </div>
  );
}

export default function App() {
  const [registering, setRegistering] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [attempted, setAttempted] = useState(false);
  const emailInvalid = attempted && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
  const passwordInvalid = attempted && !password;
  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setAttempted(true);
    setError("");
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !password) return;
    setLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 1100));
    setLoading(false);
    setError("This is a design preview. Sign-in is not connected to your authentication system yet.");
  }
  const inputClass = "h-[54px] w-full rounded-[10px] border bg-white pl-12 pr-4 text-sm text-[#17211b] outline-none transition placeholder:text-[#a0a7a2] focus:border-[#27764b] focus:ring-4 focus:ring-[#166534]/10 disabled:bg-gray-50 disabled:opacity-60";
  return (
    <main className="grid min-h-dvh bg-white font-sans text-foreground md:grid-cols-2">
      <section className="flex min-h-dvh flex-col px-7 py-8 sm:px-12 lg:px-16 lg:py-11 xl:px-[72px]">
        <header className="flex items-center gap-3.5">
          <div className="flex size-12 shrink-0 items-center justify-center rounded-[13px] bg-[#17613e] text-white"><Sprout size={28} strokeWidth={1.7} /></div>
          <div><p className="text-[19px] font-bold tracking-[-0.3px]">Aringay Agriculture</p><p className="mt-1 text-[11px] text-[#778078] sm:text-xs">Municipal Agriculture Management System</p></div>
        </header>
        {registering ? <FarmerRegistration onSignIn={() => { setRegistering(false); setPassword(""); setAttempted(false); setError(""); setShowPassword(false); }} /> : <div className="mx-auto flex w-full max-w-[400px] flex-1 flex-col justify-center py-14 md:py-16">
          <div className="mb-7 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[1.6px] text-[#43815d]"><span className="size-1.5 rounded-full bg-[#43815d]" /> Rooted in community. Growing together.</div>
          <h1 className="text-[38px] font-semibold leading-[1.2] tracking-[-1px] lg:text-[42px]">Welcome back<span className="text-[#32865b]">.</span></h1>
          <p className="mt-3 max-w-[340px] text-sm leading-6 text-[#7a827e]">Sign in to access your agriculture management account.</p>
          <form className="mt-9" onSubmit={handleSubmit} noValidate>
            {error && <div role="alert" className="mb-5 flex items-start gap-2 rounded-lg border border-amber-200 bg-amber-50 p-3 text-xs leading-5 text-amber-900"><AlertCircle size={17} className="mt-0.5 shrink-0" />{error}</div>}
            <label htmlFor="email" className="mb-2 block text-[13px] font-semibold">Email Address</label>
            <div className="relative"><Mail size={18} className="pointer-events-none absolute left-4 top-[18px] text-[#8b958e]" /><input id="email" name="email" type="email" autoComplete="username" placeholder="Enter your email address" value={email} onChange={(event) => { setEmail(event.target.value); setError(""); }} disabled={loading} aria-invalid={emailInvalid} aria-describedby={emailInvalid ? "email-error" : undefined} className={`${inputClass} ${emailInvalid ? "border-red-400" : "border-[#dfe5e0]"}`} /></div>
            {emailInvalid && <p id="email-error" className="mt-2 text-xs text-red-600" role="alert">Enter a valid email address.</p>}
            <label htmlFor="password" className="mb-2 mt-6 block text-[13px] font-semibold">Password</label>
            <div className="relative"><LockKeyhole size={18} className="pointer-events-none absolute left-4 top-[18px] text-[#8b958e]" /><input id="password" name="password" type={showPassword ? "text" : "password"} autoComplete="current-password" placeholder="Enter your password" value={password} onChange={(event) => { setPassword(event.target.value); setError(""); }} disabled={loading} aria-invalid={passwordInvalid} aria-describedby={passwordInvalid ? "password-error" : undefined} className={`${inputClass} pr-14 ${passwordInvalid ? "border-red-400" : "border-[#dfe5e0]"}`} /><button type="button" onClick={() => setShowPassword(!showPassword)} aria-label={showPassword ? "Hide password" : "Show password"} aria-pressed={showPassword} className="absolute right-1 top-1 flex size-[46px] items-center justify-center rounded-md text-[#8b958e] transition hover:text-[#166534] focus-visible:outline-2 focus-visible:outline-[#166534]">{showPassword ? <EyeOff size={18} /> : <Eye size={18} />}</button></div>
            {passwordInvalid && <p id="password-error" className="mt-2 text-xs text-red-600" role="alert">Enter your password.</p>}
            <label className="mt-5 flex w-fit cursor-pointer items-center gap-2.5 py-1 text-xs text-[#69756d]"><input name="remember" type="checkbox" disabled={loading} className="size-4 rounded border-[#dfe5e0] accent-[#166534] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#166534]" />Remember me</label>
            <button type="submit" disabled={loading} className="mt-7 flex h-[54px] w-full items-center justify-center gap-3 rounded-[10px] bg-[#17633f] text-sm font-semibold text-white shadow-sm transition hover:bg-[#104d30] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#166534] disabled:cursor-wait disabled:opacity-60">{loading ? <><LoaderCircle size={18} className="animate-spin motion-reduce:animate-none" />Signing in…</> : <>Sign In<ArrowRight size={17} /></>}</button>
          </form>
          <p className="mt-5 text-center text-xs text-[#7a827e]">Don’t have an account? <button type="button" disabled={loading} onClick={() => { setRegistering(true); setPassword(""); }} className="min-h-10 rounded px-1 font-semibold text-[#17633f] hover:underline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#166534]">Register as Farmer</button></p>
          <div className="mt-7 flex items-center justify-center gap-2 text-[11px] text-[#909992]"><ShieldCheck size={15} /> Secure access. Better service for our farmers.</div>
        </div>}
        <footer className="flex flex-wrap items-center justify-between gap-3 text-[10px] text-[#929a95]"><span>© {new Date().getFullYear()} Aringay Agriculture</span><span className="flex items-center gap-1"><MapPin size={12} />Aringay, La Union</span></footer>
      </section>
      <section className="relative hidden overflow-hidden bg-[#164e39] text-white md:flex md:min-h-dvh md:flex-col md:items-center md:justify-center md:px-8 lg:px-12" aria-label="Agriculture management overview">
        <div className="absolute inset-0 bg-radial-[at_50%_40%] from-[#2c6d4d] via-[#1b573e] to-[#123f30]" />
        <div aria-hidden="true" className="absolute inset-0 text-[#a8c49b]/15"><Sprout className="absolute left-[12%] top-[11%] size-11 -rotate-12" strokeWidth={1} /><Tractor className="absolute right-[12%] top-[17%] size-12 rotate-12" strokeWidth={1} /><Bell className="absolute right-[8%] top-[45%] size-8 rotate-12" strokeWidth={1} /><Truck className="absolute bottom-[15%] left-[8%] size-12 -rotate-12" strokeWidth={1} /><Leaf className="absolute bottom-[9%] right-[12%] size-10 rotate-12" strokeWidth={1} /><MapPin className="absolute left-[9%] top-[51%] size-9" strokeWidth={1} /></div>
        <div className="absolute right-8 top-10 flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-3.5 py-2 text-[10px] font-medium tracking-wide text-[#d3e0d4]"><span className="size-1.5 rounded-full bg-[#a7c596]" /> MUNICIPAL AGRICULTURE OFFICE</div>
        <div className="relative w-full max-w-[550px] pt-20 pb-24">
          <AgricultureScene />
          <div className="relative mx-auto mt-5 max-w-[440px] text-center">
            <p className="mb-4 text-[10px] font-medium uppercase tracking-[2.3px] text-[#b5cbaa]">Better systems. Stronger communities.</p>
            <h2 className="text-[31px] font-medium leading-[1.3] tracking-[-0.5px] lg:text-[36px]">{registering ? <>A stronger future<br />starts with our farmers.</> : <>Manage agriculture<br />resources with confidence.</>}</h2>
            <p className="mx-auto mt-5 max-w-[355px] text-[13px] leading-[1.85] text-[#b7cdbf]">{registering ? "Stay connected to local agriculture services, resource distributions, and important community updates." : "Track farmers, resources, distributions, complaints, and notifications in one secure system."}</p>
            <div className="mt-8 inline-flex items-center gap-2 text-[11px] text-[#d3dfcf]"><Sprout size={15} /> Built for Aringay. Built for our farmers.<ChevronRight size={12} className="opacity-50" /></div>
          </div>
        </div>
        <div className="absolute bottom-10 flex items-center gap-2 text-[10px] tracking-wide text-[#98b6a5]"><span className="h-px w-7 bg-[#98b6a5]/40" /> Cultivating progress, together <span className="h-px w-7 bg-[#98b6a5]/40" /></div>
      </section>
    </main>
  );
}
